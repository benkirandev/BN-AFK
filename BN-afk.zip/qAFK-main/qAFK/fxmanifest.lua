-- for support, contact me on discord qavas#0746 
fx_version 'cerulean'
games { 'gta5' }

author 'qavas'
description 'AFK Script'

client_scripts {
    'lua/client.lua',
    'config/config.lua'
}

server_scripts {
    'lua/server.lua',
    'config/config.lua'
}
ui_page "html/index.html"
files {
    'html/index.html',
    'html/js/index.js',
    'html/css/style.css',
    'config/config.js'
}
