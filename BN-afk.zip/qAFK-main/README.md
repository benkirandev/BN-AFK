# qAFK

## 🧧 About <a name = "about"></a>
A fully customizable AFK script that allows a person to go AFK, and get teleported to a place of no RP. Also includes a kick feature.

### 🌌 Dependencies

None, but this may not work on ESX or VRP.

### 💻 Installing
*more in-depth documentation on my <a href="https://qtprod.com">website</a> **SOON***

1. Add the resource to your resources folder (Must be named qAFK or it wont work.)

2. Customize both the config.lua, and config.js in the config folder.

3. Start it in your server.cfg: `start qAFK`

4. Once this is done, load it up, and have fun.

## ✨ Includes
Look at my <a href="https://forum.cfx.re/t/release-standalone-qafk/2381764">FiveM</a> post for more info.

## 🚶‍♂️ Authors
<a href="https://github.com/qavas">qavas</a> and <a href="https://github.com/apxtony">APxTony</a>

